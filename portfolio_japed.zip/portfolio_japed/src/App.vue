<script setup>
</script>

<template>
  <div id="app">
    <router-view />
    <Footer />
  </div>
</template>

<style scoped>

</style>
