<script setup></script>

<template>
<div class="py-5 bg-clr2">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <h5 class="text-light">Aqil Javed Septio</h5>
                <p class="m-0 text-light">Official portfolio site.</p>
            </div>
            <div class="col-md-4 pt-5 pt-md-0">
                <h5 class="text-light">Social media</h5>
                <div class="text-light">
                    <a href="https://instagram.com/" target="_blank" class="d-flex align-items-center gap-2 td-none text-light mb-1">
                        <i class="fab fa-instagram"></i>
                        <p class="m-0">Instagram</p>
                    </a>
                    <a href="https://linkedin.com/in/" target="_blank" class="d-flex align-items-center gap-2 td-none text-light mb-1">
                        <i class="fab fa-linkedin-in"></i>
                        <p class="m-0">Linkedin</p>
                    </a>
                    <a href="https://github.com/" target="_blank" class="d-flex align-items-center gap-2 td-none text-light mb-1">
                        <i class="fab fa-github"></i>
                        <p class="m-0">Github</p>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="py-3 bg-clr1">
    <div class="container">
        <div class="row">
            <p class="m-0 text-light">2025 | Aqil Javed Septio</p>
        </div>
    </div>
</div>
</template>

<style scoped></style>