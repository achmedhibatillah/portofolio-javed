<script setup>
</script>

<template>
<div class="w-100 bg-danger"></div>
</template>

<style scoped>
</style>