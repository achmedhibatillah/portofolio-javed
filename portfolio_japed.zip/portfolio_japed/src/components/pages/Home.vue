<script setup>
import Navbar from '../templates/Navbar.vue';
import Top from '../section/Top.vue';
import Footbar from '../templates/Footbar.vue';
</script>

<template>
  <div class="w-100">
    <Navbar page="home" />
    <Top />
    <Footbar />
  </div>
</template>

<style scoped>

</style>
